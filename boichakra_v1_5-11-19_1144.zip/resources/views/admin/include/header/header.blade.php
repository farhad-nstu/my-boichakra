
		<header id="tg-dashboardheader" class="tg-dashboardheader tg-haslayout">
			
            @include('admin.include.header.nav-left')
            
            @include('admin.include.header.nav-right')
            
            @include('admin.include.header.sidebar')
			
		</header>