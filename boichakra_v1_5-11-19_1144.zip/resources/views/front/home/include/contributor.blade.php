<section class="tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-push-1 col-lg-10">
							<div class="tg-categoriessearch">
								<div class="tg-title">
									<h2><span>Top</span> Contributor</h2>
								</div>
								<div id="tg-categoriesslider" class="tg-categoriesslider tg-categories owl-carousel">
									<div class="tg-category">
										<div class="tg-categoryholder">
											<figure><img src="images/icons/img-08.png" alt="image description"></figure>
											<h3>Mobiles</h3>
										</div>
									</div>
									<div class="tg-category">
										<div class="tg-categoryholder">
											<figure><img src="images/icons/img-09.png" alt="image description"></figure>
											<h3>Electronics</h3>
										</div>
									</div>
									<div class="tg-category">
										<div class="tg-categoryholder">
											<figure><img src="images/icons/img-10.png" alt="image description"></figure>
											<h3>Vehicles</h3>
										</div>
									</div>
									<div class="tg-category">
										<div class="tg-categoryholder">
											<figure><img src="images/icons/img-11.png" alt="image description"></figure>
											<h3>Bikes</h3>
										</div>
									</div>
									<div class="tg-category">
										<div class="tg-categoryholder">
											<figure><img src="images/icons/img-12.png" alt="image description"></figure>
											<h3>Animals</h3>
										</div>
									</div>
									<div class="tg-category">
										<div class="tg-categoryholder">
											<figure><img src="images/icons/img-13.png" alt="image description"></figure>
											<h3>Furniture</h3>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>