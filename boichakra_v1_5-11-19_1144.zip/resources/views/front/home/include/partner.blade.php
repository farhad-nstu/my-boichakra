<section class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<div id="tg-brandsslider" class="tg-brands tg-brandsslider owl-carousel">
								<figure class="item"><img src="images/brands/img-01.png" alt="image description"></figure>
								<figure class="item"><img src="images/brands/img-02.png" alt="image description"></figure>
								<figure class="item"><img src="images/brands/img-03.png" alt="image description"></figure>
								<figure class="item"><img src="images/brands/img-04.png" alt="image description"></figure>
							</div>
						</div>
					</div>
				</div>
			</section>