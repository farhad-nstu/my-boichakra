<section class="tg-sectionspace tg-bglight tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<div id="tg-testimonialsslider" class="tg-testimonials tg-testimonialsslider owl-carousel">
								<div class="item">
									<div class="tg-testimonial">
										<figure><img src="images/testimonials/img-01.jpg" alt="image description"></figure>
										<div class="tg-contentbox">
											<h2><a href="javascript:void(0);">Jami Gheen</a></h2>
											<div class="tg-description">
												<p>Consectetur adipisicing elit sed eiusmod temporie icididunt ut labore et dolore magna aliquaaenim.</p>
											</div>
											<h3>Developer at of <a href="javascript:void(0);">xyz company</a></h3>
										</div>
									</div>
								</div>
								<div class="item">
									<div class="tg-testimonial">
										<figure><img src="images/testimonials/img-02.jpg" alt="image description"></figure>
										<div class="tg-contentbox">
											<h2><a href="javascript:void(0);">Johnny Zeigler</a></h2>
											<div class="tg-description">
												<p>Consectetur adipisicing elit sed eiusmod temporie icididunt ut labore et dolore magna aliquaaenim.</p>
											</div>
											<h3>Developer at of <a href="javascript:void(0);">xyz company</a></h3>
										</div>
									</div>
								</div>
								<div class="item">
									<div class="tg-testimonial">
										<figure><img src="images/testimonials/img-01.jpg" alt="image description"></figure>
										<div class="tg-contentbox">
											<h2><a href="javascript:void(0);">Jami Gheen</a></h2>
											<div class="tg-description">
												<p>Consectetur adipisicing elit sed eiusmod temporie icididunt ut labore et dolore magna aliquaaenim.</p>
											</div>
											<h3>Developer at of <a href="javascript:void(0);">xyz company</a></h3>
										</div>
									</div>
								</div>
								<div class="item">
									<div class="tg-testimonial">
										<figure><img src="images/testimonials/img-02.jpg" alt="image description"></figure>
										<div class="tg-contentbox">
											<h2><a href="javascript:void(0);">Johnny Zeigler</a></h2>
											<div class="tg-description">
												<p>Consectetur adipisicing elit sed eiusmod temporie icididunt ut labore et dolore magna aliquaaenim.</p>
											</div>
											<h3>Developer at of <a href="javascript:void(0);">xyz company</a></h3>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>