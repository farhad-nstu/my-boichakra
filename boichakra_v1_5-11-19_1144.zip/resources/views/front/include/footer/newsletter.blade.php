<div class="tg-footerbar">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-push-1 col-lg-10">
							<div class="tg-newsletter">
								<h2>Signup For Newsletter:</h2>
								<form class="tg-formtheme tg-formnewsletter">
									<fieldset>
										<i class="icon-envelope"></i>
										<input type="email" name="email" class="form-control" placeholder="Enter your email here">
										<button type="button">Signup Now</button>
									</fieldset>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>