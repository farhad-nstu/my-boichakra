<div class="tg-topbar">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<ul class="tg-navcurrency">
								<li><a href="#" data-toggle="modal" data-target="#tg-modalselectcurrency">select currency</a></li>
								<li><a href="#" data-toggle="modal" data-target="#tg-modalpriceconverter">Price converter</a></li>
							</ul>
							
                            @include('front.include.header.user-header')
                            
						</div>
					</div>
				</div>
			</div>