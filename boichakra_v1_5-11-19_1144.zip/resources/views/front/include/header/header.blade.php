<header id="tg-header" class="tg-header tg-haslayout">
			
    @include('front.include.header.top-header')
    
    @include('front.include.header.bottom-header')
    
</header>