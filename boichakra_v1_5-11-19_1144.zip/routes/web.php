<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});


Auth::routes();




Route::get('/',[
    'uses' => 'Front\HomeController@index',
    'as' => '/'
]);

Route::group(['middleware' => 'auth'], function () {
    
    // 
    
});

Route::group(['middleware' => 'adminMiddleware'], function () {
    
     Route::get('/admin/home', 'HomeController@index')->name('home');
    
//    Category
    
    Route::get('/add-category',[
        'uses'  => 'Admin\CategoryController@addCategory',
        'as'    => 'add-category'
    ]);
    
//    Book    
    Route::get('/add-book',[
        'uses'  => 'Admin\BookController@addBook',
        'as'    => 'add-book'
    ]);

//    Book Publisher
    Route::get('/add-book-publisher',[
        'uses'  => 'Admin\BookPublisherController@addBookPublisher',
        'as'    => 'add-book-publisher'
    ]);
    
//    Book Writer
    Route::get('/add-book-writer',[
        'uses'  => 'Admin\BookWriterController@addBookWriter',
        'as'    => 'add-book-writer'
    ]);

//    Book Category    
    Route::get('/add-book-category',[
        'uses'  => 'Admin\BookCategoryController@addBookCategory',
        'as'    => 'add-book-category'
    ]);

    
});

Route::group(['middleware' => 'myUserMiddleware'], function () {
    
    Route::get('/user/home', 'HomeController@userIndex')->name('user.home');
    
});



//Category

    Route::get('/add-category', [
        'uses'  => 'Admin\CategoryController@addCategory',
        'as'    => 'add-category'
    ]);
