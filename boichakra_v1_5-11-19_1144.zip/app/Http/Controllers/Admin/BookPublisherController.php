<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BookPublisherController extends Controller
{
    public function addBookPublisher() {
        return view('admin.category.book.publisher.add-publisher');
    }
}
