<div id="tg-navigation" class="collapse navbar-collapse tg-navigation">
									<ul>
										<li class="menu-item">
											<a href="{{ route('/')}}">Home</a>
										</li>
										<li class="menu-item-has-children current-menu-item">
											<a href="javascript:void(0);">Writers</a>
											<ul class="sub-menu">
												<li><a href="javascript:void(0);">Humayun Ahamed</a></li>
												<li><a href="javascript:void(0);">Jafar Ikbal</a></li>
												<li><a href="javascript:void(0);">Anisul Haq</a></li>
											</ul>
										</li>
                                        <li class="menu-item-has-children current-menu-item">
											<a href="javascript:void(0);">Categories</a>
											<ul class="sub-menu">
												<li><a href="javascript:void(0);">Islamic</a></li>
												<li><a href="javascript:void(0);">Politics</a></li>
												<li><a href="javascript:void(0);">Freedom Fighter</a></li>
												<li><a href="javascript:void(0);">Travels</a></li>
											</ul>
										</li>
                                        <li class="menu-item-has-children current-menu-item">
											<a href="javascript:void(0);">Publishers</a>
											<ul class="sub-menu">
												<li><a href="javascript:void(0);">Sheba Prokasoni</a></li>
												<li><a href="javascript:void(0);">Prothoma Prokasoni</a></li>
												<li><a href="javascript:void(0);">Bangla Academy</a></li>
												<li><a href="javascript:void(0);">Agami Prokasoni</a></li>
											</ul>
										</li>
									</ul>
								</div>