<div class="tg-rghtbox">
				<a class="tg-btn" href="{{ route('add-book') }}">
					<i class="icon-bookmark"></i>
					<span>Post a Book</span>
				</a>
				<div class="dropdown tg-themedropdown tg-notification">
					<button class="tg-btndropdown" id="tg-notificationdropdown" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<i class="icon-alarm"></i>
						<span class="tg-badge">9</span>
					</button>
					<ul class="dropdown-menu tg-dropdownmenu" aria-labelledby="tg-notificationdropdown">
						<li><p>Consectetur adipisicing sedi eiusmod ampore incididunt ut labore et dolore.</p></li>
						<li><p>Consectetur adipisicing sedi eiusmod ampore incididunt ut labore et dolore.</p></li>
						<li><p>Consectetur adipisicing sedi eiusmod ampore incididunt ut labore et dolore.</p></li>
						<li><p>Consectetur adipisicing sedi eiusmod ampore incididunt ut labore et dolore.</p></li>
						<li><p>Consectetur adipisicing sedi eiusmod ampore incididunt ut labore et dolore.</p></li>
						<li><p>Consectetur adipisicing sedi eiusmod ampore incididunt ut labore et dolore.</p></li>
					</ul>
				</div>
			</div>